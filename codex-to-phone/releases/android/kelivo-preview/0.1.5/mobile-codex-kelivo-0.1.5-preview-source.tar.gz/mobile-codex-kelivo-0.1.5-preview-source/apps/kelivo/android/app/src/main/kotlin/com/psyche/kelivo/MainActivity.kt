package com.psyche.kelivo

import android.app.Activity
import android.content.ActivityNotFoundException
import android.net.Uri
import android.content.Intent
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.DocumentsContract
import android.view.KeyEvent
import android.webkit.MimeTypeMap
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.android.FlutterSurfaceView
import io.flutter.embedding.android.FlutterView
import io.flutter.embedding.engine.FlutterEngine
import com.psyche.kelivo.workspace.WorkspacePlugin
import io.flutter.plugin.common.MethodChannel
import com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.concurrent.Executors
import java.util.Locale

class MainActivity : FlutterActivity() {
    private val kelivo get() = application as KelivoApplication
    private var reusedEngine = false
    private val highRefreshRate by lazy { HighRefreshRateController(window) }
    private var productShell: ProductShellHandler? = null
    private var selectionMenu: AndroidSelectionMenu? = null
    override fun provideFlutterEngine(context: android.content.Context): FlutterEngine {
        reusedEngine = kelivo.hasEngine
        return kelivo.engine
    }
    override fun shouldDestroyEngineWithHost(): Boolean = false

    override fun onStart() {
        super.onStart()
        kelivo.backgroundRuntime.setForeground(true)
    }

    override fun onPostResume() {
        super.onPostResume()
        // A headless engine may have sent SystemChrome settings before its
        // Activity/PlatformPlugin existed. Apply the window policy on attach.
        applyEdgeToEdgeSystemBars(window)
        highRefreshRate.resume()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) highRefreshRate.request(force = true)
    }

    override fun onStop() {
        selectionMenu?.dismiss()
        highRefreshRate.stop()
        kelivo.backgroundRuntime.setForeground(false)
        super.onStop()
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean =
        (keyCode == KeyEvent.KEYCODE_BACK && !event.isCanceled && selectionMenu?.handleBack() == true) ||
            super.onKeyUp(keyCode, event)

    private companion object {
        const val CREATE_DOCUMENT_REQUEST_CODE = 4107
    }

    private enum class WritableFileState {
        IDLE,
        OPEN,
        COMMITTED,
        DISCARDED,
    }

    private val processTextChannelName = "app.process_text"
    private val fileSaveChannelName = "app.file_save"
    private val deviceStorageChannelName = "app.device_storage"
    private var processTextChannel: MethodChannel? = null
    private var fileSaveChannel: MethodChannel? = null
    private var deviceStorageChannel: MethodChannel? = null
    private var pendingProcessText: String? = null
     private var pendingSaveResult: MethodChannel.Result? = null
     private var pendingSaveSourcePath: String? = null
     private var pendingDirectWrite = false
     private var pendingWritableStream: OutputStream? = null
     private var pendingWritableUri: Uri? = null
     @Volatile private var writableFileState = WritableFileState.IDLE
     private val writableFileExecutor = Executors.newSingleThreadExecutor()
     private var deviceLocalToolsHandler: DeviceLocalToolsHandler? = null
     private var workspacePlugin: WorkspacePlugin? = null
    private var incomingShareHandler: IncomingShareHandler? = null
    private var receivedShare = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        productShell?.receive(intent)
        forwardCachedProcessTextLaunch(reusedEngine, savedInstanceState, intent, processTextChannel)
        (kelivo.engine.plugins.get(FlutterLocalNotificationsPlugin::class.java) as? FlutterLocalNotificationsPlugin)?.let {
            forwardCachedNotificationLaunch(reusedEngine, savedInstanceState, intent, it)
        }
        kelivo.backgroundRuntime.receiveConversation(intent)
        receivedShare = savedInstanceState?.getBoolean("kelivo.receivedShare") == true
        if (!receivedShare) receivedShare = incomingShareHandler?.receive(intent) == true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("kelivo.receivedShare", receivedShare)
        super.onSaveInstanceState(outState)
    }

    override fun onFlutterSurfaceViewCreated(flutterSurfaceView: FlutterSurfaceView) {
        super.onFlutterSurfaceViewCreated(flutterSurfaceView)
        highRefreshRate.attach(flutterSurfaceView)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
         super.configureFlutterEngine(flutterEngine)
        productShell = ProductShellHandler(this, flutterEngine.dartExecutor.binaryMessenger)
        kelivo.messageInput.attachActivity(this)
        selectionMenu = AndroidSelectionMenu(flutterEngine.dartExecutor.binaryMessenger) {
            findViewById<FlutterView>(FlutterActivity.FLUTTER_VIEW_ID)
        }
        incomingShareHandler = IncomingShareHandler(this, flutterEngine.dartExecutor.binaryMessenger)
         OAuthHandler.configure(this, flutterEngine.dartExecutor.binaryMessenger)
         kelivo.backgroundRuntime.attachActivity(this)
         deviceLocalToolsHandler = kelivo.deviceTools.also { it.attachActivity(this) }
         workspacePlugin = kelivo.workspace.also { it.attachActivity(this) }
        processTextChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, processTextChannelName)
        processTextChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialText" -> {
                    val text = pendingProcessText ?: takeProcessText(intent)
                    pendingProcessText = null
                    result.success(text)
                }
                else -> result.notImplemented()
            }
        }
        fileSaveChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, fileSaveChannelName)
        fileSaveChannel?.setMethodCallHandler { call, result ->
            // DartMessenger may have queued this handler before it was removed.
            if (fileSaveChannel == null) {
                result.error("cancelled", "The file picker was closed.", null)
                return@setMethodCallHandler
            }
            when (call.method) {
                "saveFileFromPath" -> handleSaveFileFromPath(call.arguments, result)
                "createWritableFile" -> handleCreateWritableFile(call.arguments, result)
                "writeWritableFileChunk" -> handleWriteWritableFileChunk(call.arguments, result)
                "completeWritableFile" -> handleCompleteWritableFile(result)
                "abortWritableFile" -> handleAbortWritableFile(result)
                else -> result.notImplemented()
            }
        }
        deviceStorageChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceStorageChannelName)
        deviceStorageChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "freeBytes" -> result.success(usableBytesForAppData())
                else -> result.notImplemented()
            }
        }
    }

    /**
     * Space the app may still use on the volume holding its data, or null when
     * it cannot be determined. Callers treat null as "unknown" and carry on.
     */
    private fun usableBytesForAppData(): Long? = try {
        val target = filesDir ?: dataDir
        StatFs(target.absolutePath).availableBytes.takeIf { it > 0 }
    } catch (_: Exception) {
        null
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        productShell?.receive(intent)
        kelivo.backgroundRuntime.receiveConversation(intent)
        setIntent(intent)
        receivedShare = incomingShareHandler?.receive(intent) == true
        val text = takeProcessText(intent) ?: return
        val ch = processTextChannel
        if (ch != null) {
            ch.invokeMethod("onProcessText", text)
        } else {
            pendingProcessText = text
        }
    }

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        // The shared engine can move to another Activity before this one is
        // destroyed. Remove these handlers during detach, before its new host
        // registers replacements on the same messenger.
        productShell?.dispose()
        productShell = null
        kelivo.messageInput.detachActivity(this)
        selectionMenu?.dispose()
        selectionMenu = null
        deviceLocalToolsHandler?.detachActivity(this)
        kelivo.backgroundRuntime.detachActivity(this)
        OAuthHandler.detachActivity(this)
        processTextChannel?.setMethodCallHandler(null)
        processTextChannel = null
        fileSaveChannel?.setMethodCallHandler(null)
        fileSaveChannel = null
        deviceStorageChannel?.setMethodCallHandler(null)
        deviceStorageChannel = null
        finishPendingSave(pendingSaveResult) {
            it.error("cancelled", "The file picker was closed.", null)
        }
        val stream = pendingWritableStream
        val uri = pendingWritableUri
        if (stream != null && uri != null) {
            writableFileExecutor.execute {
                // Serialized after all queued writes/completion. A successful
                // completion marks COMMITTED before posting its UI callback,
                // so an intact backup is never deleted in this race window.
                if (writableFileState == WritableFileState.OPEN) {
                    discardWritableDestination(stream, uri)
                }
            }
        }
        // Submitted writes and cleanup finish, but this detached host is done.
        writableFileExecutor.shutdown()
        incomingShareHandler?.dispose()
        incomingShareHandler = null
        workspacePlugin?.detachActivity(this)
        super.cleanUpFlutterEngine(flutterEngine)
    }

    override fun onDestroy() {
        highRefreshRate.dispose()
        super.onDestroy()
    }
 
     override fun onRequestPermissionsResult(
         requestCode: Int,
         permissions: Array<out String>,
         grantResults: IntArray,
     ) {
         if (workspacePlugin?.onRequestPermissionsResult(requestCode) == true) return
        if (kelivo.backgroundRuntime.permissionResult(requestCode)) return
         if (deviceLocalToolsHandler?.onRequestPermissionsResult(requestCode, grantResults) == true) {
             return
         }
         super.onRequestPermissionsResult(requestCode, permissions, grantResults)
     }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (workspacePlugin?.onActivityResult(requestCode, resultCode, data) == true) return
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != CREATE_DOCUMENT_REQUEST_CODE) {
            return
        }

        val destUri = if (resultCode == Activity.RESULT_OK) data?.data else null
        handleSaveDestination(destUri)
    }

    private fun handleSaveFileFromPath(arguments: Any?, result: MethodChannel.Result) {
        if (pendingSaveResult != null || pendingWritableStream != null) {
            result.error("busy", "Another save operation is already in progress.", null)
            return
        }

        val args = arguments as? Map<*, *>
        val rawSourcePath = (args?.get("sourcePath") as? String).orEmpty()
        if (rawSourcePath.isEmpty()) {
            result.error("invalid_args", "Missing sourcePath.", null)
            return
        }

        val sourceFile = File(rawSourcePath)
        if (!sourceFile.exists() || !sourceFile.isFile) {
            result.error("not_found", "Source file does not exist.", null)
            return
        }

        val suggestedFileName = (args?.get("fileName") as? String).takeUnless { it.isNullOrEmpty() }
            ?: sourceFile.name

        pendingSaveResult = result
        pendingSaveSourcePath = sourceFile.absolutePath

        try {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = fileSaveMimeType(suggestedFileName)
                putExtra(Intent.EXTRA_TITLE, suggestedFileName)
            }
            startActivityForResult(intent, CREATE_DOCUMENT_REQUEST_CODE)
        } catch (e: ActivityNotFoundException) {
            finishPendingSave(result) { it.error("launch_failed", e.message, null) }
        }
    }

    private fun handleCreateWritableFile(arguments: Any?, result: MethodChannel.Result) {
        if (pendingSaveResult != null || pendingWritableStream != null) {
            result.error("busy", "Another save operation is already in progress.", null)
            return
        }

        val args = arguments as? Map<*, *>
        val fileName = args?.get("fileName")?.toString()?.trim().orEmpty()
        if (fileName.isEmpty()) {
            result.error("invalid_args", "Missing fileName.", null)
            return
        }

        pendingSaveResult = result
        pendingDirectWrite = true
        try {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, fileName)
            }
            startActivityForResult(intent, CREATE_DOCUMENT_REQUEST_CODE)
        } catch (e: ActivityNotFoundException) {
            finishPendingSave(result) { it.error("launch_failed", e.message, null) }
        }
    }

    private fun handleCompleteWritableFile(result: MethodChannel.Result) {
        val stream = pendingWritableStream
        if (stream == null) {
            result.error("not_open", "No writable file destination is open.", null)
            return
        }

        writableFileExecutor.execute {
            try {
                stream.flush()
                stream.close()
                writableFileState = WritableFileState.COMMITTED
                runOnUiThread {
                    if (pendingWritableStream === stream) {
                        pendingWritableStream = null
                        pendingWritableUri = null
                    }
                    result.success(true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    result.error("close_failed", e.message, null)
                }
            }
        }
    }

    private fun handleWriteWritableFileChunk(arguments: Any?, result: MethodChannel.Result) {
        val stream = pendingWritableStream
        if (stream == null) {
            result.error("not_open", "No writable file destination is open.", null)
            return
        }
        val bytes = arguments as? ByteArray
        if (bytes == null) {
            result.error("invalid_args", "Missing writable file bytes.", null)
            return
        }
        if (bytes.isEmpty()) {
            result.success(true)
            return
        }

        writableFileExecutor.execute {
            try {
                stream.write(bytes)
                runOnUiThread { result.success(true) }
            } catch (e: Exception) {
                runOnUiThread {
                    result.error("write_failed", e.message, null)
                }
            }
        }
    }

    private fun handleAbortWritableFile(result: MethodChannel.Result) {
        val stream = pendingWritableStream
        val uri = pendingWritableUri
        if (stream == null || uri == null) {
            result.error("not_open", "No writable file destination is open.", null)
            return
        }

        writableFileExecutor.execute {
            val cleanupError = discardWritableDestination(stream, uri)

            runOnUiThread {
                if (pendingWritableStream === stream) {
                    pendingWritableStream = null
                    pendingWritableUri = null
                }
                if (cleanupError == null) {
                    result.success(true)
                } else {
                    result.error("discard_failed", cleanupError.message, null)
                }
            }
        }
    }

    private fun discardWritableDestination(stream: OutputStream, uri: Uri): Exception? {
        var cleanupError: Exception? = null
        try {
            stream.close()
        } catch (e: Exception) {
            cleanupError = e
        }

        var deleted = false
        try {
            deleted = DocumentsContract.deleteDocument(contentResolver, uri)
            if (!deleted) {
                cleanupError = cleanupError
                    ?: IllegalStateException("Unable to delete incomplete destination file.")
            }
        } catch (e: Exception) {
            cleanupError = cleanupError ?: e
        }
        if (deleted) {
            writableFileState = WritableFileState.DISCARDED
        }
        return cleanupError
    }

    // All callers run on the main thread. Clear the matching request before
    // replying so cancellation, completion and a late worker cannot reply twice.
    private fun finishPendingSave(
        expected: MethodChannel.Result?,
        reply: (MethodChannel.Result) -> Unit,
    ) {
        if (expected == null || pendingSaveResult !== expected) return
        pendingSaveResult = null
        pendingSaveSourcePath = null
        pendingDirectWrite = false
        reply(expected)
    }

    private fun handleSaveDestination(destUri: Uri?) {
        val result = pendingSaveResult ?: return
        if (pendingDirectWrite) {
            if (destUri == null) {
                finishPendingSave(result) { it.success(null) }
                return
            }
            try {
                pendingWritableUri = destUri
                val descriptor = contentResolver.openFileDescriptor(destUri, "rwt")
                    ?: throw IllegalStateException("Unable to open destination file.")
                pendingWritableStream = ParcelFileDescriptor.AutoCloseOutputStream(descriptor)
                writableFileState = WritableFileState.OPEN
                finishPendingSave(result) { it.success(true) }
            } catch (e: Exception) {
                try {
                    DocumentsContract.deleteDocument(contentResolver, destUri)
                } catch (_: Exception) {
                    // Preserve the error that prevented the destination from opening.
                }
                pendingWritableUri = null
                finishPendingSave(result) { it.error("open_failed", e.message, null) }
            }
            return
        }
        val sourcePath = pendingSaveSourcePath

        if (destUri == null || sourcePath.isNullOrEmpty()) {
            finishPendingSave(result) { it.success(false) }
            return
        }

        Thread {
            try {
                contentResolver.openOutputStream(destUri)?.use { outputStream ->
                    FileInputStream(File(sourcePath)).use { inputStream ->
                        inputStream.copyTo(outputStream, DEFAULT_BUFFER_SIZE)
                    }
                } ?: throw IllegalStateException("Unable to open destination stream.")

                runOnUiThread {
                    finishPendingSave(result) { it.success(true) }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    finishPendingSave(result) { it.error("save_failed", e.message, null) }
                }
            }
        }.start()
    }
}

internal fun fileSaveMimeType(fileName: String): String =
    MimeTypeMap.getSingleton()
        .getMimeTypeFromExtension(File(fileName).extension.lowercase(Locale.ROOT))
        ?: "application/octet-stream"

/** Cold launches are read by HomePage; a retained HomePage instead needs an
 * event when Android creates its replacement Activity. Consume the extra so
 * restoring that Activity or querying initial text cannot deliver it twice. */
internal fun forwardCachedProcessTextLaunch(
    reusedEngine: Boolean,
    savedState: Bundle?,
    intent: Intent,
    channel: MethodChannel?,
) {
    if (reusedEngine && savedState == null && channel != null &&
        intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY == 0) {
        takeProcessText(intent)?.let { channel.invokeMethod("onProcessText", it) }
    }
}

internal fun takeProcessText(intent: Intent?): String? {
    if (intent?.action != Intent.ACTION_PROCESS_TEXT) return null
    val text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
    intent.removeExtra(Intent.EXTRA_PROCESS_TEXT)
    return text?.trim()?.takeIf { it.isNotEmpty() }
}

/** The notifications plugin queries cold launches once from Dart. A new
 * Activity on an existing engine needs its new notification Intent forwarded,
 * because onAttachedToActivity does not deliver a normal notification tap. */
internal fun forwardCachedNotificationLaunch(
    reusedEngine: Boolean,
    savedState: Bundle?,
    intent: Intent,
    plugin: FlutterLocalNotificationsPlugin,
) {
    if (reusedEngine && savedState == null &&
        intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY == 0) {
        plugin.onNewIntent(intent)
    }
}
