# MobiCodex 整合预览：code10 对应源码

此归档对应 Android 预览 0.1.8-native-preview / versionCode 10。
APK 包名 com.mobilecodex.kelivo.preview，arm64-v8a，Android 7.0/API24 起。
APK SHA256: 55cd1ba56009fde374f2964c560a6f6a0224aba8e0555c79096b3583f7b3c049
Kelivo 固定 v1.3.4 / 4a7da9b6f5d77caccb9f8aaf656232a93ab14708。

## 来源与许可

整合程序按随附 LICENSE（GNU AGPL v3）提供；Kelivo 原许可见 apps/kelivo/LICENSE。
原 Codex To Phone 代码的 MIT 许可及版权声明保留于 LICENSE.mobile-codex。
各本地依赖的原 LICENSE/NOTICE 保留，原生 Termux 来源见 dependencies/termux/README.md。
修改范围与各源码文件 SHA256 见 SOURCE-MANIFEST.json；来源基线见 integrations/kelivo。
此包是对应工作区快照，不能用父仓库旧提交替代。

## 构建

需要 Node.js 22+、Corepack/pnpm 10.20.0、固定 Flutter 3.47.6
（commit 5fc346839b5d0eef006ed8404392afb4dfae428d）、Android SDK36、
NDK28.2.13676358、CMake3.22.1、JDK17及JDK21+。编译/测试验证为JDK25。
运行 corepack pnpm install --frozen-lockfile；Flutter 路径由 KELIVO_FLUTTER 指定。
设置 ANDROID_HOME、MOBILE_CODEX_LINT_JAVA_HOME（JDK17）、
MOBILE_CODEX_COMPILE_JAVA_HOME / MOBILE_CODEX_TEST_JAVA_HOME（JDK21+）。
运行 node scripts/verify-kelivo.mjs --preview --repeat-tests。
详细命令见 integrations/kelivo/README.md；更新通道由 update-channel.json 固定为整合预览通道。
依赖由固定锁/工具版本下载；不包含本机SDK、缓存、个人配置、签名私钥或用户数据。
使用自己的 Android Debug 密钥签名；证书与生成的 Web build ID 不同，不承诺APK字节复现。

## 本预览范围

用户选定电脑/手机黑白图标用于 Android 图标、启动画面与内置品牌图，用户可见品牌统一为 MobiCodex。
应用 ID、签名、OAuth、数据库、备份和工具协议保持兼容；原始开源归属保留。
图标及 Flutter 原生资源通过 App 内 APK 覆盖安装更新，不能由现有 Web 热更新替换。
AI、电脑、设置统一入口；两个功能可独立使用，可主动交接单条正文至已有电脑会话。
支持设置内 APK 检查、下载、校验与系统安装确认；整合热更新未接通。
电脑执行说明始终可见，连续工具的详细命令与输出默认动态折叠；字号与工具显示跟随 Kelivo 偏好。
所有电脑 Agent 共用 Codex 的输入、工具摘要、图片、大图、附件和语音；按钮遵守原通道能力。
DeepSeek原生/PTC、Claude和OpenCode投影可见工具；后续SessionAdapter复用同一工作区。
项目内 Markdown 图片支持鉴权加载与大图；本地取图需同步构建并升级电脑网关及原宿主插件。
GitHub 版本包与自托管更新通道分别交付；本次源码提交不会自动更新在线通道或网关。
code4/5 需先手动覆盖安装本版本一次，之后可在 App 内更新。
代码保留与部分测试不代表59组全部验收。原Desktop新建、真机/最低系统及完整真实联动继续待验。
